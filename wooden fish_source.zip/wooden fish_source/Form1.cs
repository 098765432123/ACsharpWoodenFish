﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*------------------分割线--------------------------
 ------------------dividing line---------------------*/
namespace wooden_fish
{
    public partial class window : Form
    {
        private Point mPoint;

        public int click = 0; 
        public window()
        {

            
            this.BackColor = Color.White;
            this.TransparencyKey = Color.White;
            InitializeComponent();
        }
        /*----------------------------分割线-------------------------------------
         -------------------------------Dividing line------------------------------------*/

        private void button1_Click(object sender, EventArgs e)
         //鼠标点击事件
        {


            //MessageBox.Show("well");
            //被注释掉的测试用代码
        }
        /***************The above event is useless****************/
        /****************上面的事件没用**********************/
        /*------------------------------分割线-----------------------------------------
         ------------------------------dividing line--------------------------------------*/
        //初始化
        //Initialize
        private void window_Load(object sender, EventArgs e)
        {
            click_lb.Text = "click:";
            click_lb_s.Text = "0";
            pictureBox1.Image = Image.FromFile(@"wooden fish2.png");
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            click++;
            string str_click = click.ToString();
            click_lb.Text = "click:";
            click_lb_s.Text = str_click;
            pictureBox1.Image = Image.FromFile(@"wooden fish.png");
            //MessageBox.Show("well");
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            pictureBox1.Image = Image.FromFile(@"wooden fish2.png");
        }
    }
}
